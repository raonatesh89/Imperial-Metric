﻿using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Metric_Imperial.Models
{
    public class RateRepository
    {
        private string constr;

        public RateRepository()
        {
            constr = @"Persist Security Info=false;User ID=sa;password=123;Initial Catalog=Metric_Imperial;Data Source=ASWS\SQL2014;Connection Timeout=100000";

        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(constr);
            }
        }

        public Rate GetRates()
        {
            using(IDbConnection dbCon = Connection)
            {
                string sql = @"SELECT * FROM RATE_MASTER";
                dbCon.Open();
                return dbCon.Query<Rate>(sql).FirstOrDefault(); //Rates are fetched from database
                //Rate objRate = new Rate();
                //objRate.Rate_CM_Inch = 0.3937;
                //objRate.Metric_Rate_Cel_Far = 1.8;
                //objRate.Imperial_Rate_Far_Cel = 0.56;
                //objRate.Rate_Kg_Lb = 2.2046;
                //return objRate;
            }
        }
    }
}
