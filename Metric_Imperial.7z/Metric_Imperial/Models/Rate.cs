﻿namespace Metric_Imperial.Models
{
    public class Rate
    {
        public double Rate_CM_Inch { get; set; } //0.03937
        public double Rate_Kg_Lb { get; set; } //2.2046
        public double Metric_Rate_Cel_Far { get; set; } // multiply by 9/5 then add 32
        public double Imperial_Rate_Far_Cel { get; set; } //subtract 32 then multiply 5/9
    }
}
