﻿using Metric_Imperial.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;

namespace Metric_Imperial.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatesController : ControllerBase
    {
        private readonly RateRepository rateRepository;
        public const int temp = 32;
        public RatesController()
        {
            rateRepository = new RateRepository();
        }
       
        [HttpGet]
        [Route("GetImperial")]
        public string ConvertToImperial(double cm, double kg, double celsius)
        {
            string msg = "Nothing to display";
            Rate objRates = new Rate();
            objRates = rateRepository.GetRates(); //getting rates from database using dapper
            if (cm > 0 && kg > 0 && celsius > 0)
            {
                double inch = cm * objRates.Rate_CM_Inch;
                double lb = kg * objRates.Rate_Kg_Lb;
                double faranite = (celsius * objRates.Metric_Rate_Cel_Far) + temp;

                return "For Centimetres " + cm + " inch is " + inch + " inches.For Kilograms " + kg + " pounds is " + lb + "lbs.For Celsius temperature is " + faranite + " faranite.";

            }
            else
            {
                msg = "Values for Centimetres,Kilograms and Celsius must greater than 0";
            }

            return msg;

        }

        [HttpGet]
        [Route("GetMetric")]
        public string ConvertToMetric(double inch, double lb, double faranite)
        {
            string msg = "Nothing to display";
            Rate objRates = new Rate();
            objRates = rateRepository.GetRates(); //getting rates from database using dapper
            if (inch > 0 && lb > 0 && faranite > 0)
            {
                double cm = inch / objRates.Rate_CM_Inch;
                double kg = lb / objRates.Rate_Kg_Lb;
                double celsius = (faranite  - temp) * objRates.Imperial_Rate_Far_Cel;

                return "For Inches " + inch + " centimetres is " + cm + " cm.For Pounds " + lb + " Kilograms is " + kg + "kg.For Faranite temperature is " + celsius + " celsius.";

            }
            else
            {
                msg = "Values for Inches,Pounds and Faranite must greater than 0";
            }

            return msg;

        }
    }
}
